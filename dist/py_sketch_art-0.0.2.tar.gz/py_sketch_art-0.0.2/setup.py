from setuptools import setup, find_packages
import codecs
import os

VERSION = '0.0.2' # Initial version for the reworked package
DESCRIPTION = 'A Python library for animating drawings of images and generating ASCII art.'
LONG_DESCRIPTION = """
# Welcome to Sketchpy (Reimagined)

This is a reimagined and refactored version of the `sketchpy` library, designed for easier use and better organization. It allows you to create drawing animations from images, generate ASCII art, and draw predefined celebrity sketches using the `turtle` module.

## Features

- **Image Sketching**: Convert any image into a line-drawing animation.
- **ASCII Art Generation**: Transform images into ASCII art.
- **SVG Sketching**: Draw complex SVG paths.
- **Predefined Drawings**: Sketch famous personalities like APJ Abdul Kalam, Vijay, Tom Holland, and Robert Downey Jr.
- **Simplified Interface**: Run all operations from a single script with command-line arguments.

## Installation

To install the `sketchpy` library, you can use pip:

```bash
pip install sketchpy
```

**Note**: This package is currently under development and not yet available on PyPI. The installation instructions will be updated once it's published.

## Usage

The library provides a simplified command-line interface through `run_sketchpy.py` to perform various operations. You can use it as follows:

```bash
python run_sketchpy.py --operation <operation_name> [arguments]
```

### Operations

#### 1. Image Sketching (`sketch`)

This operation converts an image into a line drawing. It includes an automatic tracing feature, so you only need to provide the image path.

**Example:**

```bash
python run_sketchpy.py --operation sketch --image_path path/to/your/image.jpg --save True --retain True
```

**Arguments:**
- `--image_path`: Path to the input image (required).
- `--save`: Save the drawn sketch as a PNG file (default: `False`).
- `--retain`: Keep the drawing window open after sketching (default: `False`).
- `--x_offset`: X-offset for the drawing position (default: `300`).
- `--y_offset`: Y-offset for the drawing position (default: `300`).
- `--mode`: Drawing mode (1 for lines, 0 for fill; default: `1`).
- `--thickness`: Line thickness for drawing (default: `1`).
- `--threshold`: Threshold for automatic edge detection during tracing (default: `100`).
- `--simplify_factor`: Factor to simplify the number of points in the trace (default: `5`).

#### 2. ASCII Art Generation (`ascii`)

Convert an image into ASCII art, displayed using the `turtle` module.

**Example:**

```bash
python run_sketchpy.py --operation ascii --image_path path/to/your/image.png --save True
```

**Arguments:**
- `--image_path`: Path to the input image (required).
- `--save`: Save the ASCII art as a screenshot (default: `True`).
- `--x_len`: Pixel movement in X direction (default: `5`).
- `--y_len`: Pixel movement in Y direction (default: `7`).

#### 3. SVG Sketching (`svg`)

Draw an image from an SVG file. Note that this feature might require additional setup for proper rendering, as the original library's SVG handling is complex.

**Example:**

```bash
python run_sketchpy.py --operation svg --image_path path/to/your/vector.svg --scale 500
```

**Arguments:**
- `--image_path`: Path to the SVG file (required).
- `--scale`: Zoom value for the SVG (default: `500`).
- `--x_offset`: X-offset for the drawing position (default: `0`).
- `--y_offset`: Y-offset for the drawing position (default: `0`).
- `--save`: Save the drawn sketch as a PNG file (default: `True`).

#### 4. Predefined Drawings (`apj`, `vijay`, `tom_holland`, `rdj`)

Draw predefined sketches of famous personalities.

**Examples:**

```bash
python run_sketchpy.py --operation apj
python run_sketchpy.py --operation vijay
python run_sketchpy.py --operation tom_holland
python run_sketchpy.py --operation rdj
```

**Arguments (common for predefined drawings):**
- `--x_offset`: X-offset for the drawing position (default: `300` or `370` depending on the drawing).
- `--y_offset`: Y-offset for the drawing position (default: `300`).
- `--retain`: Keep the drawing window open after sketching (default: `True` for some, `False` for others in original).

## Development & Contribution

Feel free to contribute to this project by submitting pull requests or reporting issues. The goal is to make `sketchpy` more robust, user-friendly, and feature-rich.

## License

This project is licensed under the [MIT License](https://github.com/MRMYSTERY003/sketchpy/blob/main/LICENSE).

"""

setup(
    name="py-sketch-art", # Changed to a more generic name
    version=VERSION,
    author="Mr Mystery (Original) & Manus AI (Refactoring)",
    author_email="sriramanand23@gmail.com", # Original author's email
    description=DESCRIPTION,
    long_description_content_type="text/markdown",
    long_description=LONG_DESCRIPTION,
    packages=find_packages(where="sketchpy"), # Look for packages in the 'sketchpy' directory
    package_dir={'': 'sketchpy'}, # Map the root of the package to the 'sketchpy' directory
    include_package_data=True,
    install_requires=[
        'opencv-python',
        'Pillow',
        'svg.path',
        'svgpathtools',
        'tqdm',
        'numpy',

        # 'torch', # Optional, if AI features are fully integrated and optimized
        # 'requests', # Only if external APIs are used
        # 'geocoder', # Only if location services are used
        # 'geopy', # Only if location services are used
    ],
    keywords=[
        'python', 'sketch', 'drawing', 'animation', 'pencil sketch', 'painting', 
        'sketchpy', 'draw', 'sketching', 'ascii art', 'image processing'
    ],
    classifiers=[
        "Development Status :: 3 - Alpha", # Changed to Alpha as it's a refactored version
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent", # More general
    ],
)

